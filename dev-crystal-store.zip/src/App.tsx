import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import { motion } from "motion/react";
import { Instagram, Mail, Phone, ShoppingBag, ArrowRight, User } from "lucide-react";

import { subscribeProducts } from "./lib/firestore";
import LoginPage from "./components/Auth/LoginPage";
import AdminDashboard from "./components/Admin/AdminDashboard";

const FALLBACK_PRODUCTS = [
  {
    id: "1",
    name: "Amethyst Radiance",
    price: "Rp 450.000",
    image: "https://images.unsplash.com/photo-1599643478524-fb524b07f8df?w=500&q=80",
    description: "Natural amethyst for spiritual clarity."
  },
  {
    id: "2",
    name: "Rose Quartz Pure",
    price: "Rp 320.000",
    image: "https://images.unsplash.com/photo-1587301669862-22129598858a?w=500&q=80",
    description: "Gentle rose quartz for unconditional love."
  },
  {
    id: "3",
    name: "Clear Obsidian Focus",
    price: "Rp 550.000",
    image: "https://images.unsplash.com/photo-1567360425618-1594206637d2?w=500&q=80",
    description: "Sharp obsidian for protection and grounding."
  }
];

function LandingPage() {
  const [products, setProducts] = useState<any[]>([]);

  useEffect(() => {
    const unsubscribe = subscribeProducts((data) => {
      if (data.length > 0) {
        setProducts(data);
      } else {
        setProducts(FALLBACK_PRODUCTS);
      }
    });
    return () => unsubscribe();
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div id="home" className="min-h-screen bg-[#fcfcfc] text-gray-900 font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 w-full px-6 md:px-12 py-6 flex justify-between items-center bg-white/70 backdrop-blur-md z-50 border-b border-black/5">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-2xl font-bold font-serif tracking-tight"
        >
          <Link to="/">dev <span className="text-crystal-blue">Crystal</span></Link>
        </motion.div>
        <ul className="hidden md:flex gap-8 items-center list-none">
          {["Beranda", "Katalog", "Kontak"].map((item) => (
            <li key={item}>
              <a 
                href={item.toLowerCase() === "beranda" ? "#home" : `#${item.toLowerCase()}`}
                className="text-xs font-medium uppercase tracking-widest hover:text-crystal-blue transition-colors"
              >
                {item}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <Link 
            to="/admin" 
            className="p-2 text-gray-400 hover:text-crystal-blue transition-colors rounded-full hover:bg-gray-50"
            title="Admin Dashboard"
          >
            <User className="w-5 h-5" />
          </Link>
          <button className="p-2 text-gray-900 transition-colors rounded-full hover:bg-gray-50">
            <ShoppingBag className="w-5 h-5" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col justify-center items-center text-center px-6 bg-gradient-to-br from-[#f5f7fa] to-[#c3cfe2] overflow-hidden">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1, ease: "easeOut" }}
           className="absolute inset-0 z-0 flex justify-center items-center opacity-20 pointer-events-none"
        >
          <div className="w-[500px] h-[500px] rounded-full bg-blue-200 blur-[100px]" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="relative z-10 max-w-3xl"
        >
          <h1 className="text-5xl md:text-7xl font-serif mb-6 leading-tight text-gray-900">
            Keindahan di Setiap <span className="italic">Sudut</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-xl mx-auto leading-relaxed">
            Temukan koleksi eksklusif dari dev Crystal Store. Simpel, elegan, dan dirancang khusus untuk memenuhi gaya hidup Anda.
          </p>
          <motion.a 
            href="#katalog"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-full font-medium text-sm transition-all hover:bg-crystal-blue shadow-lg shadow-black/10"
          >
            Lihat Koleksi <ArrowRight className="w-4 h-4" />
          </motion.a>
        </motion.div>
      </section>

      {/* Catalog Section */}
      <section id="katalog" className="py-24 px-6 md:px-12 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-serif mb-4"
          >
            Koleksi Kami
          </motion.h2>
          <div className="w-12 h-1 bg-crystal-blue mx-auto" />
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {products.map((product) => (
            <motion.div 
              key={product.id}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-black/5"
            >
              <div className="h-64 overflow-hidden relative group">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-medium mb-1 font-serif">{product.name}</h3>
                <p className="text-sm text-gray-500 mb-4 line-clamp-1">{product.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-crystal-blue font-semibold">{product.price}</span>
                  <button 
                    onClick={() => alert(`Mengarahkan ke WhatsApp untuk ${product.name}...`)}
                    className="p-2 rounded-full border border-gray-200 hover:bg-gray-900 hover:text-white transition-colors"
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Footer */}
      <footer id="kontak" className="bg-white border-t border-black/5 py-16 px-6 md:px-12">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="flex flex-col gap-4">
            <div className="text-xl font-bold font-serif">dev <span className="text-crystal-blue">Crystal</span></div>
            <p className="text-sm text-gray-500 max-w-xs transition-colors">
              Menghadirkan keindahan alam ke dalam rumah Anda dengan koleksi kristal pilihan terbaik.
            </p>
          </div>
          
          <div className="flex flex-col gap-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400">Tautan Cepat</h4>
            <ul className="flex flex-col gap-2 list-none">
              <li><a href="#home" className="text-sm text-gray-500 hover:text-crystal-blue transition-colors">Beranda</a></li>
              <li><a href="#katalog" className="text-sm text-gray-500 hover:text-crystal-blue transition-colors">Katalog</a></li>
              <li><a href="#kontak" className="text-sm text-gray-500 hover:text-crystal-blue transition-colors">Kontak</a></li>
            </ul>
          </div>

          <div className="flex flex-col gap-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400">Hubungi Kami</h4>
            <div className="flex gap-4">
              <a href="#" className="p-2 bg-gray-50 rounded-full hover:bg-crystal-blue hover:text-white transition-all"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="p-2 bg-gray-50 rounded-full hover:bg-crystal-blue hover:text-white transition-all"><Phone className="w-4 h-4" /></a>
              <a href="#" className="p-2 bg-gray-50 rounded-full hover:bg-crystal-blue hover:text-white transition-all"><Mail className="w-4 h-4" /></a>
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto pt-8 border-t border-black/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400">
          <p>&copy; 2026 dev Crystal Store. All Rights Reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-gray-900 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  const [isAdmin, setIsAdmin] = useState(localStorage.getItem('admin_auth') === 'true');

  const handleLogin = (status: boolean) => {
    setIsAdmin(status);
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_auth');
    setIsAdmin(false);
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route 
          path="/login" 
          element={isAdmin ? <Navigate to="/admin" /> : <LoginPage onLogin={handleLogin} />} 
        />
        <Route 
          path="/admin" 
          element={isAdmin ? <AdminDashboard onLogout={handleLogout} /> : <Navigate to="/login" />} 
        />
      </Routes>
    </BrowserRouter>
  );
}
