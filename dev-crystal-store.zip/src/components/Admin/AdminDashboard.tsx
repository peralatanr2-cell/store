import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  LogOut, 
  LayoutDashboard, 
  Package, 
  Settings as SettingsIcon,
  X,
  Save,
  Image as ImageIcon
} from 'lucide-react';
import { subscribeProducts, addProduct, updateProduct, deleteProduct } from '../../lib/firestore';

interface AdminDashboardProps {
  onLogout: () => void;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [products, setProducts] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    image: '',
    description: ''
  });

  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeProducts((data) => {
      setProducts(data);
    });
    return () => unsubscribe();
  }, []);

  const handleOpenModal = (product: any = null) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        price: product.price,
        image: product.image,
        description: product.description
      });
    } else {
      setEditingProduct(null);
      setFormData({ name: '', price: '', image: '', description: '' });
    }
    setIsModalOpen(true);
  };

  const [message, setMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, formData);
        setMessage({ text: 'Produk berhasil diperbarui!', type: 'success' });
      } else {
        await addProduct(formData);
        setMessage({ text: 'Produk berhasil ditambahkan!', type: 'success' });
      }
      setIsModalOpen(false);
    } catch (error) {
      setMessage({ text: 'Gagal menyimpan produk.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (deletingId === id) {
      setLoading(true);
      try {
        await deleteProduct(id);
        setMessage({ text: 'Produk berhasil dihapus!', type: 'success' });
        setDeletingId(null);
      } catch (error) {
        setMessage({ text: 'Gagal menghapus produk.', type: 'error' });
      } finally {
        setLoading(false);
      }
    } else {
      setDeletingId(id);
      setTimeout(() => setDeletingId(null), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-black/5 flex flex-col p-6 hidden md:flex">
        <div className="text-xl font-bold font-serif mb-10">dev <span className="text-crystal-blue">Admin</span></div>
        <nav className="flex-1 space-y-2">
          <button className="w-full flex items-center gap-3 px-4 py-3 bg-gray-900 text-white rounded-xl text-sm transition-all text-left">
            <Package className="w-4 h-4" /> Katalog Produk
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 text-gray-500 hover:bg-gray-100 rounded-xl text-sm transition-all text-left">
            <SettingsIcon className="w-4 h-4" /> Pengaturan Web
          </button>
        </nav>
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-xl text-sm transition-all text-left mt-auto"
        >
          <LogOut className="w-4 h-4" /> Keluar
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-12 overflow-y-auto">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-serif">Katalog Produk</h1>
            <p className="text-sm text-gray-400">Kelola item yang muncul di landing page</p>
          </div>
          <button 
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 px-6 py-3 bg-crystal-blue text-white rounded-full text-sm font-medium hover:bg-blue-600 transition-all shadow-lg shadow-blue-200"
          >
            <Plus className="w-4 h-4" /> Tambah Produk
          </button>
        </header>

        {/* Message Toast */}
        <AnimatePresence>
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`fixed top-6 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-2xl shadow-xl text-white text-sm font-medium ${
                message.type === 'success' ? 'bg-green-500' : 'bg-red-500'
              }`}
            >
              {message.text}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Product Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {products.map((product) => (
            <motion.div 
              layout
              key={product.id}
              className="bg-white rounded-2xl p-4 border border-black/5 flex gap-4 items-center shadow-sm"
            >
              <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 bg-gray-100">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium truncate">{product.name}</h3>
                <p className="text-sm text-crystal-blue font-semibold">{product.price}</p>
                <p className="text-xs text-gray-400 line-clamp-1 mt-1">{product.description}</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleOpenModal(product)}
                  className="p-2 text-gray-400 hover:text-crystal-blue hover:bg-blue-50 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(product.id)}
                  className={`p-2 rounded-lg transition-all flex items-center gap-2 ${
                    deletingId === product.id 
                      ? 'bg-red-500 text-white text-xs px-3' 
                      : 'text-gray-400 hover:text-red-500 hover:bg-red-50'
                  }`}
                >
                  {deletingId === product.id ? 'Hapus?' : <Trash2 className="w-4 h-4" />}
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
            <Package className="w-12 h-12 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400">Belum ada produk. Silakan tambah produk baru.</p>
          </div>
        )}
      </main>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-black/5 flex justify-between items-center bg-gray-50/50">
                <h2 className="text-xl font-serif">{editingProduct ? 'Edit Produk' : 'Tambah Produk Baru'}</h2>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-black/5 rounded-full transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Nama Produk</label>
                    <input 
                      type="text" 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-crystal-blue transition-all"
                      placeholder="Contoh: Amethyst Radiance"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Harga</label>
                    <input 
                      type="text" 
                      value={formData.price}
                      onChange={e => setFormData({...formData, price: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-crystal-blue transition-all"
                      placeholder="Contoh: Rp 450.000"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-400 block">Gambar Produk</label>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                       <p className="text-[10px] text-gray-400 mb-1">Pilih dari perangkat Anda:</p>
                       <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-200 rounded-2xl cursor-pointer hover:bg-gray-50 hover:border-crystal-blue transition-all group">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <ImageIcon className="w-6 h-6 text-gray-400 group-hover:text-crystal-blue mb-2" />
                          <p className="text-xs text-gray-500">Klik untuk upload</p>
                        </div>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              if (file.size > 800 * 1024) {
                                setMessage({ text: 'Gambar terlalu besar! Gunakan gambar di bawah 800KB agar berhasil disimpan.', type: 'error' });
                                return;
                              }
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                setFormData({...formData, image: reader.result as string});
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                    </div>

                    <div className="space-y-2">
                      <p className="text-[10px] text-gray-400 mb-1">Atau tempel URL gambar:</p>
                      <div className="relative">
                        <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input 
                          type="url" 
                          value={formData.image}
                          onChange={e => setFormData({...formData, image: e.target.value})}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-crystal-blue transition-all text-xs"
                          placeholder="https://..."
                        />
                      </div>
                      {formData.image && (
                        <div className="mt-2 h-16 w-full rounded-lg overflow-hidden border border-black/5">
                          <img src={formData.image} className="w-full h-full object-cover" alt="Preview" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Deskripsi Singkat</label>
                  <textarea 
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    rows={3}
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-crystal-blue transition-all resize-none"
                    placeholder="Jelaskan sedikit tentang produk ini..."
                    required
                  />
                </div>

                <button 
                  disabled={loading}
                  type="submit"
                  className="w-full py-4 bg-gray-900 text-white rounded-2xl font-medium hover:bg-crystal-blue transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
                >
                  {loading ? 'Menyimpan...' : (
                    <>
                      <Save className="w-4 h-4" /> {editingProduct ? 'Simpan Perubahan' : 'Publish Produk'}
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
