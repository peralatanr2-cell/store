# Security Specification - dev Crystal Store

## 1. Data Invariants
- Products must have a name, price, image, and description.
- Only authorized admins can create, update, or delete products.
- Store settings (hero content) can only be modified by admins.
- Public users can read all products and settings.

## 2. The "Dirty Dozen" Payloads
These payloads should be rejected by the rules:
1. Create a product as an unauthenticated user.
2. Update a product's price to a non-string value.
3. Inject a huge string (>1KB) into the product description.
4. Modify the `updatedAt` field to a past timestamp.
5. Create a product with missing required fields (e.g., no `image`).
6. Update a product with "Ghost Fields" (e.g., `isFeatured: true`).
7. Attempt to delete a product as a non-admin.
8. Attempt to read a non-existent `private_data` collection.
9. Bulk update products via a single write (if not in batch).
10. Spoofing identity by providing a fake `adminId` in the payload.
11. Setting `price` to a negative number (though stored as string, we can't check value easily, but we check type).
12. Attempt to list all documents in the `/admins` collection.

## 3. Test Runner (Conceptual)
A test suite should verify:
- `get` / `list` on `/products` is ALLOWED for everyone.
- `create` / `update` / `delete` on `/products` is DENIED for `auth == null`.
- `create` / `update` / `delete` on `/products` is ALLOWED for users in `admins` collection.
